-- MariaDB dump 10.19  Distrib 10.4.32-MariaDB, for Win64 (AMD64)
--
-- Host: localhost    Database: edupilot
-- ------------------------------------------------------
-- Server version	10.4.32-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admins`
--

DROP TABLE IF EXISTS `admins`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`admin_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admins`
--

LOCK TABLES `admins` WRITE;
/*!40000 ALTER TABLE `admins` DISABLE KEYS */;
INSERT INTO `admins` VALUES (4,'Admin','edupilot8@gmail.com','scrypt:32768:8:1$DEipo58poDIxrFwO$57e5b4345e4d20d3f0ed81d22353f865fda136ac659ca8af26bd6aff1b71799b6ee27ad63014a2ac5750ba6f8470a47d990bf0bad42882899767f2a1b5d0a079','2026-08-20 09:28:54');
/*!40000 ALTER TABLE `admins` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `events`
--

DROP TABLE IF EXISTS `events`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `events` (
  `event_id` int(11) NOT NULL AUTO_INCREMENT,
  `event_name` varchar(150) NOT NULL,
  `event_type` enum('Academic','Sports','Meeting','Social','Other') NOT NULL,
  `event_date` date NOT NULL,
  `event_time` time NOT NULL,
  `venue` varchar(150) NOT NULL,
  `organizer` varchar(150) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `events`
--

LOCK TABLES `events` WRITE;
/*!40000 ALTER TABLE `events` DISABLE KEYS */;
INSERT INTO `events` VALUES (1,'SPORT DAY','Sports','2026-09-30','09:00:00','RUC','Sharen','2026-08-18 15:33:55'),(3,'Laptop','Academic','2026-09-29','11:39:00','Idk','LarnieG','2026-09-17 09:36:56');
/*!40000 ALTER TABLE `events` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `marks`
--

DROP TABLE IF EXISTS `marks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `marks` (
  `mark_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  `teacher_id` int(11) NOT NULL,
  `class_name` varchar(20) NOT NULL,
  `assessment_type` varchar(50) NOT NULL,
  `term` int(11) NOT NULL,
  `mark` decimal(5,2) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`mark_id`),
  UNIQUE KEY `student_id` (`student_id`,`subject_id`,`assessment_type`,`term`),
  KEY `subject_id` (`subject_id`),
  KEY `teacher_id` (`teacher_id`),
  CONSTRAINT `marks_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`),
  CONSTRAINT `marks_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`),
  CONSTRAINT `marks_ibfk_3` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`),
  CONSTRAINT `chk_mark` CHECK (`mark` >= 0 and `mark` <= 100),
  CONSTRAINT `chk_term` CHECK (`term` between 1 and 4)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `marks`
--

LOCK TABLES `marks` WRITE;
/*!40000 ALTER TABLE `marks` DISABLE KEYS */;
INSERT INTO `marks` VALUES (1,5,3,7,'12A','Test 1',1,40.00,'2026-08-21 07:12:36'),(2,5,3,7,'12A','Assignment',1,20.00,'2026-08-21 07:12:44'),(3,5,3,7,'12A','Exam',1,46.00,'2026-08-21 07:12:52'),(4,5,2,7,'12A','Test 1',1,65.00,'2026-08-22 06:46:42'),(5,5,2,7,'12A','Assignment',1,70.00,'2026-08-22 06:46:46'),(6,5,2,7,'12A','Exam',1,95.00,'2026-08-22 06:46:55'),(7,7,2,8,'10A','Test 1',1,20.00,'2026-08-22 07:19:28'),(8,7,2,8,'10A','Assignment',1,20.00,'2026-08-22 07:19:37'),(9,7,2,8,'10A','Exam',1,69.00,'2026-08-22 07:19:47'),(10,7,1,8,'10A','Test 1',1,60.00,'2026-08-22 07:21:59'),(11,7,1,8,'10A','Assignment',1,60.00,'2026-08-22 07:22:07'),(12,7,1,8,'10A','Exam',1,70.00,'2026-08-22 07:22:16'),(13,7,3,8,'10A','Test 1',1,50.00,'2026-08-22 07:22:47'),(14,6,3,8,'10A','Test 1',1,95.00,'2026-08-22 07:22:47'),(15,7,3,8,'10A','Assignment',1,50.00,'2026-08-22 07:22:54'),(16,6,3,8,'10A','Assignment',1,90.00,'2026-08-22 07:22:54'),(17,7,3,8,'10A','Exam',1,60.00,'2026-08-22 07:23:03'),(18,6,3,8,'10A','Exam',1,80.00,'2026-08-22 07:23:03'),(19,5,1,7,'12A','Test 1',1,55.00,'2026-08-23 08:29:41'),(20,5,1,7,'12A','Assignment',1,70.00,'2026-08-23 08:29:48'),(21,5,1,7,'12A','Exam',1,80.00,'2026-08-23 08:29:57'),(22,9,2,9,'11A','Test 1',1,11.00,'2026-08-24 05:13:54'),(23,9,2,9,'11A','Assignment',1,10.00,'2026-08-24 05:14:05'),(25,9,2,9,'11A','Exam',1,10.00,'2026-08-24 05:14:37'),(27,5,2,7,'12A','Test 1',2,75.00,'2026-08-30 08:06:11'),(28,5,2,7,'12A','Assignment',2,0.00,'2026-08-30 08:06:21'),(29,5,2,7,'12A','Exam',2,100.00,'2026-08-30 08:07:30'),(31,5,1,7,'12A','Test 1',2,100.00,'2026-08-30 08:15:08'),(32,5,1,7,'12A','Assignment',2,52.00,'2026-08-30 08:16:29'),(33,5,1,7,'12A','Exam',2,55.00,'2026-08-30 08:17:46'),(34,5,1,7,'12A','Test 1',4,12.00,'2026-09-29 12:02:05'),(35,5,2,7,'12A','Assignment',3,59.00,'2026-10-10 09:44:27');
/*!40000 ALTER TABLE `marks` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_subjects`
--

DROP TABLE IF EXISTS `student_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student_subjects` (
  `student_subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  PRIMARY KEY (`student_subject_id`),
  UNIQUE KEY `student_id` (`student_id`,`subject_id`),
  KEY `subject_id` (`subject_id`),
  CONSTRAINT `student_subjects_ibfk_1` FOREIGN KEY (`student_id`) REFERENCES `students` (`student_id`) ON DELETE CASCADE,
  CONSTRAINT `student_subjects_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_subjects`
--

LOCK TABLES `student_subjects` WRITE;
/*!40000 ALTER TABLE `student_subjects` DISABLE KEYS */;
INSERT INTO `student_subjects` VALUES (9,5,1),(10,5,2),(11,5,3),(12,6,3),(13,7,1),(14,7,2),(15,7,3),(18,9,1),(19,9,2),(20,9,3),(26,15,1),(27,15,2);
/*!40000 ALTER TABLE `student_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `students`
--

DROP TABLE IF EXISTS `students`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `students` (
  `student_id` int(11) NOT NULL AUTO_INCREMENT,
  `student_name` varchar(100) NOT NULL,
  `student_number` varchar(20) NOT NULL,
  `grade` varchar(10) NOT NULL,
  `class_name` varchar(20) NOT NULL,
  `emergency_contact_name` varchar(100) DEFAULT NULL,
  `emergency_contact_number` varchar(20) DEFAULT NULL,
  `allergy_details` text DEFAULT NULL,
  PRIMARY KEY (`student_id`),
  UNIQUE KEY `student_number` (`student_number`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `students`
--

LOCK TABLES `students` WRITE;
/*!40000 ALTER TABLE `students` DISABLE KEYS */;
INSERT INTO `students` VALUES (5,'Dylan Mothilall','402309996','12','12A','John','0824625014','Nothing'),(6,'Jordon','402309991','10','10A','Johnny','0824625011','Nothing'),(7,'Farah','402301112','10','10A','jordon','0822465178','NONE'),(9,'Jimmy','402301115','11','11A','Sharen','0721499889','Hello peter reviews'),(15,'Udhav','402301114','9','9A','Ziyaad Hajaree','0739823300','Girls');
/*!40000 ALTER TABLE `students` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `subjects`
--

DROP TABLE IF EXISTS `subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `subjects` (
  `subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `subject_name` varchar(100) NOT NULL,
  PRIMARY KEY (`subject_id`),
  UNIQUE KEY `subject_name` (`subject_name`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `subjects`
--

LOCK TABLES `subjects` WRITE;
/*!40000 ALTER TABLE `subjects` DISABLE KEYS */;
INSERT INTO `subjects` VALUES (2,'English'),(3,'Life Orientation'),(1,'Mathematics');
/*!40000 ALTER TABLE `subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `system_logs`
--

DROP TABLE IF EXISTS `system_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system_logs` (
  `log_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_id` int(11) DEFAULT NULL,
  `user_name` varchar(100) NOT NULL,
  `role` varchar(20) NOT NULL,
  `action` varchar(100) NOT NULL,
  `details` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT current_timestamp(),
  PRIMARY KEY (`log_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_logs`
--

LOCK TABLES `system_logs` WRITE;
/*!40000 ALTER TABLE `system_logs` DISABLE KEYS */;
INSERT INTO `system_logs` VALUES (1,4,'Admin','admin','Login','User has Logged in','127.0.0.1','2026-09-29 14:00:49'),(2,7,'Dylan','teacher','Login','User has Logged in','127.0.0.1','2026-09-29 14:01:45'),(3,4,'Admin','admin','Login','User has Logged in','127.0.0.1','2026-10-10 11:42:49'),(4,7,'Dylan','teacher','Login','User has Logged in','127.0.0.1','2026-10-10 11:44:05'),(5,4,'Admin','admin','Login','User has Logged in','127.0.0.1','2026-10-26 17:44:41'),(6,7,'Dylan','teacher','Login','User has Logged in','127.0.0.1','2026-10-26 18:14:59'),(7,4,'Admin','admin','Login','User has Logged in','127.0.0.1','2026-10-26 18:17:02'),(8,7,'Dylan','teacher','Login','User has Logged in','127.0.0.1','2026-10-26 18:22:48'),(9,4,'Admin','admin','Login','User has Logged in','127.0.0.1','2026-10-26 18:31:17');
/*!40000 ALTER TABLE `system_logs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_classes`
--

DROP TABLE IF EXISTS `teacher_classes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_classes` (
  `teacher_class_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `class_name` varchar(20) NOT NULL,
  PRIMARY KEY (`teacher_class_id`),
  UNIQUE KEY `teacher_id` (`teacher_id`,`class_name`),
  CONSTRAINT `teacher_classes_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_classes`
--

LOCK TABLES `teacher_classes` WRITE;
/*!40000 ALTER TABLE `teacher_classes` DISABLE KEYS */;
INSERT INTO `teacher_classes` VALUES (11,7,'12A'),(10,8,'10A'),(16,9,'11A'),(15,9,'9A');
/*!40000 ALTER TABLE `teacher_classes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_subjects`
--

DROP TABLE IF EXISTS `teacher_subjects`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teacher_subjects` (
  `teacher_subject_id` int(11) NOT NULL AUTO_INCREMENT,
  `teacher_id` int(11) NOT NULL,
  `subject_id` int(11) NOT NULL,
  PRIMARY KEY (`teacher_subject_id`),
  UNIQUE KEY `teacher_id` (`teacher_id`,`subject_id`),
  KEY `subject_id` (`subject_id`),
  CONSTRAINT `teacher_subjects_ibfk_1` FOREIGN KEY (`teacher_id`) REFERENCES `teachers` (`teacher_id`) ON DELETE CASCADE,
  CONSTRAINT `teacher_subjects_ibfk_2` FOREIGN KEY (`subject_id`) REFERENCES `subjects` (`subject_id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_subjects`
--

LOCK TABLES `teacher_subjects` WRITE;
/*!40000 ALTER TABLE `teacher_subjects` DISABLE KEYS */;
INSERT INTO `teacher_subjects` VALUES (14,7,1),(15,7,2),(16,7,3),(11,8,1),(12,8,2),(13,8,3),(22,9,1),(23,9,2),(24,9,3);
/*!40000 ALTER TABLE `teacher_subjects` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teachers`
--

DROP TABLE IF EXISTS `teachers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `teachers` (
  `teacher_id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `subjects` text DEFAULT NULL,
  `classes` text DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`teacher_id`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teachers`
--

LOCK TABLES `teachers` WRITE;
/*!40000 ALTER TABLE `teachers` DISABLE KEYS */;
INSERT INTO `teachers` VALUES (7,'Dylan','dylan.mothilall@gmail.com','scrypt:32768:8:1$1oLow3i48w41Ue91$49c879b09462e94833615d414b55af0f0d4e7f76b4c49f8c3ad87e04a65f26b5428d8a1879d3dd9a888c05ca58f013c7b0f235e149a545646310c44eb6a5c5c9','Mathematics, English, Physical Science','12A','2026-08-20 05:58:26'),(8,'Jaden','jdhevpal@gmail.com','scrypt:32768:8:1$XdUdg58V0DFVYxfh$f6c04f361d921e12988d1bfd4c1e66a9677d8eae344ded18107fc293da9812e9cfec26b7fe46fc4963fd50e7a6206618b1cd9aff2dae164b23651b83166c6cf5','Mathematics, English, Physical Science','10A','2026-08-20 09:46:27'),(9,'Tasvir','tasvirpunwasi@gmail.com','scrypt:32768:8:1$Iu6HRkDjXeKZ4Zfv$546d2c30d5af9aa9eb8a546c6ad80372950051c2d9914911c213aacbec9feeadcd85dab9a60185bdadcbc9be677a58d0832bb96c9fe0fe4a6eec7e9562ab0f9e','Mathematics, English, Physical Science','9A, 11A','2026-08-24 05:10:10');
/*!40000 ALTER TABLE `teachers` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-10-26 19:27:46
