let calendarDate = new Date();
let dashboardEvents = [];

const monthNames = [
    "January", "February", "March", "April", "May", "June",
    "July", "August", "September", "October", "November", "December"
];

function pad(value) {
    return String(value).padStart(2, "0");
}

function dateKey(year, month, day) {
    return `${year}-${pad(month + 1)}-${pad(day)}`;
}

function formatTime(time) {
    if (!time) return "";
    const [hourText, minute] = String(time).split(":");
    let hour = Number(hourText);
    const suffix = hour >= 12 ? "PM" : "AM";
    hour = hour % 12 || 12;
    return `${hour}:${minute} ${suffix}`;
}

function renderCalendar() {
    const year = calendarDate.getFullYear();
    const month = calendarDate.getMonth();
    const daysElement = document.getElementById("days");
    const titleElement = document.getElementById("monthYear");

    if (!daysElement || !titleElement) return;

    titleElement.textContent = `${monthNames[month]} ${year}`;
    daysElement.innerHTML = "";

    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();

    for (let i = 0; i < firstDay; i++) {
        const empty = document.createElement("div");
        empty.className = "day empty-day";
        daysElement.appendChild(empty);
    }

    for (let day = 1; day <= daysInMonth; day++) {
        const cell = document.createElement("div");
        cell.className = "day";
        cell.textContent = day;

        const key = dateKey(year, month, day);
        const hasEvent = dashboardEvents.some(event => event.event_date === key);

        if (
            day === today.getDate() &&
            month === today.getMonth() &&
            year === today.getFullYear()
        ) {
            cell.classList.add("today");
        }

        if (hasEvent) {
            cell.classList.add("event");
            cell.title = "Event scheduled";
        }

        cell.addEventListener("click", () => showEventsForDate(key));
        daysElement.appendChild(cell);
    }
}

function showEventsForDate(key) {
    const list = document.getElementById("eventList");
    if (!list) return;

    const matching = dashboardEvents.filter(event => event.event_date === key);
    list.innerHTML = "";

    if (!matching.length) {
        list.innerHTML = "<li>No events on this date.</li>";
        return;
    }

    matching.forEach(event => {
        const item = document.createElement("li");
        item.innerHTML = `
            <strong>${escapeHTML(event.event_name || "School event")}</strong><br>
            ${escapeHTML(event.event_type || "Event")}
            ${event.event_time ? ` · ${escapeHTML(formatTime(event.event_time))}` : ""}
            ${event.venue ? `<br><span>${escapeHTML(event.venue)}</span>` : ""}
        `;
        list.appendChild(item);
    });
}

function showUpcomingEvents() {
    const list = document.getElementById("eventList");
    if (!list) return;

    const todayKey = dateKey(
        new Date().getFullYear(),
        new Date().getMonth(),
        new Date().getDate()
    );

    const upcoming = dashboardEvents.filter(event => event.event_date >= todayKey).slice(0, 4);
    list.innerHTML = "";

    if (!upcoming.length) {
        list.innerHTML = "<li>No upcoming events.</li>";
        return;
    }

    upcoming.forEach(event => {
        const item = document.createElement("li");
        item.innerHTML = `
            <strong>${escapeHTML(event.event_name || "School event")}</strong><br>
            ${escapeHTML(event.event_date || "")}
            ${event.event_time ? ` · ${escapeHTML(formatTime(event.event_time))}` : ""}
            ${event.venue ? `<br><span>${escapeHTML(event.venue)}</span>` : ""}
        `;
        list.appendChild(item);
    });
}

async function loadEvents() {
    try {
        const response = await fetch("/api/teacher/events");
        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || "Could not load events");
        }

        dashboardEvents = Array.isArray(result.events) ? result.events : [];
        renderCalendar();
        showUpcomingEvents();
    } catch (error) {
        console.error("Dashboard events error:", error);
        dashboardEvents = [];
        renderCalendar();
        const list = document.getElementById("eventList");
        if (list) list.innerHTML = "<li>Unable to load events.</li>";
    }
}

async function loadDashboardStats() {
    try {
        const response = await fetch("/api/teacher/dashboard-stats", {
            credentials: "same-origin"
        });
        const result = await response.json();

        if (!response.ok || !result.success) {
            throw new Error(result.message || "Could not load dashboard statistics");
        }

        const studentCount = document.getElementById("studentCount");
        const classCount = document.getElementById("classCount");
        const averageMark = document.getElementById("averageMark");

        if (studentCount) studentCount.textContent = result.students;
        if (classCount) classCount.textContent = result.classes;
        if (averageMark) {
            averageMark.textContent = result.average_mark > 0
                ? `${result.average_mark}%`
                : "--";
        }
    } catch (error) {
        console.error("Dashboard statistics error:", error);
    }
}

function escapeHTML(value) {
    const div = document.createElement("div");
    div.textContent = String(value ?? "");
    return div.innerHTML;
}

document.addEventListener("DOMContentLoaded", () => {
    document.getElementById("prev")?.addEventListener("click", () => {
        calendarDate.setMonth(calendarDate.getMonth() - 1);
        renderCalendar();
    });

    document.getElementById("next")?.addEventListener("click", () => {
        calendarDate.setMonth(calendarDate.getMonth() + 1);
        renderCalendar();
    });

    renderCalendar();
    loadDashboardStats();
    loadEvents();
});

function openTeacherEventModal() {
    const modal = document.getElementById("teacherEventModal");
    const form = document.getElementById("teacherEventForm");

    if (!modal || !form) return;

    form.reset();

    const today = new Date();
    const year = today.getFullYear();
    const month = String(today.getMonth() + 1).padStart(2, "0");
    const day = String(today.getDate()).padStart(2, "0");

    document.getElementById("teacherEventDate").min = `${year}-${month}-${day}`;
    modal.classList.add("show");
}

function closeTeacherEventModal() {
    document.getElementById("teacherEventModal")?.classList.remove("show");
}

document.addEventListener("DOMContentLoaded", function() {
    const form = document.getElementById("teacherEventForm");
    const modal = document.getElementById("teacherEventModal");

    if (!form || !modal) return;

    form.addEventListener("submit", async function(event) {
        event.preventDefault();

        const eventDate = document.getElementById("teacherEventDate").value;
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const selectedDate = new Date(eventDate + "T00:00:00");

        if (selectedDate < today) {
            alert("You cannot add an event for a past date.");
            return;
        }

        const eventData = {
            event_name: document.getElementById("teacherEventName").value.trim(),
            event_type: document.getElementById("teacherEventType").value,
            event_date: eventDate,
            event_time: document.getElementById("teacherEventTime").value,
            venue: document.getElementById("teacherEventVenue").value.trim()
        };

        if (!eventData.event_name || !eventData.event_type || !eventData.event_date ||
            !eventData.event_time || !eventData.venue) {
            alert("Please complete all fields.");
            return;
        }

        try {
            const response = await fetch("/api/teacher/events", {
                method: "POST",
                headers: {
                    "Content-Type": "application/json"
                },
                credentials: "same-origin",
                body: JSON.stringify(eventData)
            });

            const result = await response.json();

            if (!response.ok || !result.success) {
                alert(result.message || "Could not add event.");
                return;
            }

            closeTeacherEventModal();
            await loadEvents();
            alert("Event added successfully!");
        } catch (error) {
            console.error("ADD TEACHER EVENT ERROR:", error);
            alert("Could not connect to the Flask server.");
        }
    });

    modal.addEventListener("click", function(event) {
        if (event.target === modal) {
            closeTeacherEventModal();
        }
    });

    document.addEventListener("keydown", function(event) {
        if (event.key === "Escape") {
            closeTeacherEventModal();
        }
    });
});
