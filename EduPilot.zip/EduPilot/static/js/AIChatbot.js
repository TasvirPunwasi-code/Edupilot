const CHATBOT_API = "/api/chatbot";
let waitingForResponse = false;

async function sendMessage(){
    const input = document.getElementById("chatInput");
    const message = input.value.trim();
    if (!message || waitingForResponse) return;

    hideWelcome();
    addUserMessage(message);
    input.value = "";
    autoResize(input);
    setLoading(true);
    const typingMessage = addTypingMessage();

    try {
        const response = await fetch(CHATBOT_API, {
            method: "POST",
            headers: {"Content-Type": "application/json"},
            body: JSON.stringify({message})
        });
        const result = await response.json();
        typingMessage.remove();

        if (!response.ok) {
            addAIMessage(result.message || "The assistant could not process your request.");
            return;
        }

        const assistantResponse = result.response || result.reply || result.message;
        addAIMessage(assistantResponse || "The chatbot returned an empty response.");
    } catch (error) {
        console.error("CHATBOT ERROR:", error);
        typingMessage.remove();
        addAIMessage("I could not connect to the chatbot server. Please check that your Flask application and chatbot endpoint are running.");
    } finally {
        setLoading(false);
        input.focus();
    }
}

function addUserMessage(message){
    const container = document.getElementById("chatContainer");
    const messageDiv = document.createElement("div");
    messageDiv.className = "message user-message";
    messageDiv.innerHTML = `
        <div class="message-avatar user">T</div>
        <div class="message-content">
            <div class="message-name">You</div>
            <p>${escapeHTML(message)}</p>
        </div>`;
    container.appendChild(messageDiv);
    scrollChat();
}

function addAIMessage(message){
    const container = document.getElementById("chatContainer");
    const messageDiv = document.createElement("div");
    messageDiv.className = "message ai-message";
    messageDiv.innerHTML = `
        <div class="message-avatar"></div>
        <div class="message-content">
            <div class="message-name">EduPilot Assistant</div>
            <p>${escapeHTML(message)}</p>
        </div>`;
    container.appendChild(messageDiv);
    scrollChat();
}

function addTypingMessage(){
    const container = document.getElementById("chatContainer");
    const messageDiv = document.createElement("div");
    messageDiv.className = "message ai-message typing";
    messageDiv.innerHTML = `
        <div class="message-avatar"></div>
        <div class="message-content">
            <div class="message-name">EduPilot Assistant</div>
            <p><span class="typing-dots"><i></i><i></i><i></i></span></p>
        </div>`;
    container.appendChild(messageDiv);
    scrollChat();
    return messageDiv;
}

function sendSuggestion(message){
    const input = document.getElementById("chatInput");
    input.value = message;
    autoResize(input);
    sendMessage();
}

function setLoading(isLoading){
    waitingForResponse = isLoading;
    document.getElementById("sendButton").disabled = isLoading;
    document.getElementById("chatInput").disabled = isLoading;
}

function scrollChat(){
    const container = document.getElementById("chatContainer");
    requestAnimationFrame(() => { container.scrollTop = container.scrollHeight; });
}

function hideWelcome(){
    const welcome = document.getElementById("welcomeBlock");
    if (welcome) welcome.style.display = "none";
}

function clearChat(){
    const container = document.getElementById("chatContainer");
    container.innerHTML = `
        <div class="welcome-block" id="welcomeBlock">
            <div class="welcome-icon"></div>
            <h2>How can I help you today?</h2>
            <p>Ask me about teaching strategies, learner interventions, revision planning or academic feedback.</p>
        </div>
        <div class="message ai-message">
            <div class="message-avatar"></div>
            <div class="message-content">
                <div class="message-name">EduPilot Assistant</div>
                <p>Hello! I’m ready to help with your teaching tasks.</p>
                <p>Give me the academic information you are authorised to share, and I can help you analyse it or turn it into a practical plan.</p>
            </div>
        </div>`;
    document.getElementById("chatInput").focus();
}

function autoResize(textarea){
    textarea.style.height = "auto";
    textarea.style.height = Math.min(textarea.scrollHeight, 110) + "px";
}

function escapeHTML(text){
    const div = document.createElement("div");
    div.textContent = String(text ?? "");
    return div.innerHTML;
}

function showNotifications(){
    alert("No new notifications.");
}

function logout(){
    if (confirm("Are you sure you want to logout?")) window.location.href = "/logout";
}

document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById("chatInput");
    input.addEventListener("input", () => autoResize(input));
    input.addEventListener("keydown", event => {
        if (event.key === "Enter" && !event.shiftKey) {
            event.preventDefault();
            sendMessage();
        }
    });
});
