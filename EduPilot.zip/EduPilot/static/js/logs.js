let logs = [];

/* LOAD LOGS */

async function loadLogs() {
    try {
        const response = await fetch("/api/admin/logs");
        const result = await response.json();

        if (!response.ok || !result.success) {
            alert(result.message || "Could not load system logs.");
            return;
        }

        logs = result.logs;
        displayLogs(logs);

        document.getElementById("totalLogs").textContent = logs.length;
    } catch (error) {
        console.error("Load logs error:", error);
    }
}

/* DISPLAY LOGS */

function displayLogs(data) {
    const table = document.getElementById("logsTable");
    const emptyMessage = document.getElementById("emptyMessage");

    table.innerHTML = "";

    if (data.length === 0) {
        emptyMessage.style.display = "block";
        return;
    }

    emptyMessage.style.display = "none";

    data.forEach(function (log) {
        const row = document.createElement("tr");

        row.innerHTML = `
            <td>${escapeHTML(log.created_at)}</td>
            <td>${escapeHTML(log.user_name)}</td>
            <td>${escapeHTML(log.role)}</td>
            <td>${escapeHTML(log.action)}</td>
            <td>${escapeHTML(log.details || "")}</td>
            <td>${escapeHTML(log.ip_address || "")}</td>
        `;

        table.appendChild(row);
    });
}

/* SEARCH LOGS */

document.getElementById("logSearch").addEventListener("input", function () {
    const search = this.value.toLowerCase().trim();

    const filtered = logs.filter(function (log) {
        return (
            String(log.user_name || "").toLowerCase().includes(search) ||
            String(log.role || "").toLowerCase().includes(search) ||
            String(log.action || "").toLowerCase().includes(search) ||
            String(log.details || "").toLowerCase().includes(search) ||
            String(log.ip_address || "").toLowerCase().includes(search) ||
            String(log.created_at || "").toLowerCase().includes(search)
        );
    });

    displayLogs(filtered);
});

/* ESCAPE HTML */

function escapeHTML(value) {
    const div = document.createElement("div");
    div.textContent = String(value ?? "");

    return div.innerHTML;
}

/* DARK MODE TOGGLE */

document.addEventListener("DOMContentLoaded", function () {
    const darkModeBtn = document.querySelector(".dark-mode");

    if (darkModeBtn) {
        // Optional: Remember user preference using localStorage
        if (localStorage.getItem("darkMode") === "enabled") {
            document.body.classList.add("dark-mode-active");
        }

        darkModeBtn.addEventListener("click", function () {
            document.body.classList.toggle("dark-mode-active");

            // Save preference to localStorage
            if (document.body.classList.contains("dark-mode-active")) {
                localStorage.setItem("darkMode", "enabled");
            } else {
                localStorage.setItem("darkMode", "disabled");
            }
        });
    }
});

/* PAGE LOAD */

document.addEventListener("DOMContentLoaded", function () {
    loadLogs();
});