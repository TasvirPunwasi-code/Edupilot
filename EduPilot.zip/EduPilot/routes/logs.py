# Imports Flask tools for routes, JSON responses, templates, request data and user sessions
from flask import Blueprint, jsonify, render_template, request, session

# Imports the function used to connect to the MySQL database
from db import get_db_connection

# Imports the security check that allows only administrators
from routes.security import admin_required

# Creates a Blueprint for all system log routes
logs_bp = Blueprint("logs", __name__)

# CREATE SYSTEM LOG

# Creates a function used to record actions performed by users into the database
def create_log(action, details=""):
    # Initializes database connection and cursor variables to None
    connection = None
    cursor = None

    # Starts error handling for database logging
    try:
        # Connects to the MySQL database
        connection = get_db_connection()
        
        # Creates a database cursor
        cursor = connection.cursor()

        # Gets the logged-in user's ID, name, role and remote IP address from the request session
        user_id = session.get("user_id")
        user_name = session.get("name", "Unknown")
        role = session.get("role", "Unknown")
        ip_address = request.remote_addr

        # Executes the SQL query to insert a new system log entry
        cursor.execute(
            """
            INSERT INTO system_logs
            (user_id, user_name, role, action, details, ip_address)
            VALUES (%s, %s, %s, %s, %s, %s)
            """,
            (user_id, user_name, role, action, details, ip_address),
        )

        # Commits the transaction to save the log in the database
        connection.commit()

    # Catches any errors that occur during the logging process
    except Exception as error:
        # Prints the logging error in the terminal for debugging
        print("Log error:", error)

    # Ensures database resources are always cleaned up
    finally:
        # Closes the database cursor if it exists
        if cursor:
            cursor.close()
        # Closes the database connection if it exists
        if connection:
            connection.close()

# LOGS PAGE

# Creates the route used to open the system logs page
@logs_bp.route("/admin/logs")

# Makes sure only an administrator can access the logs page
@admin_required
def logs_page():
    # Loads the system logs HTML page along with user session details
    return render_template(
        "AdminLogs.html",
        user_name=session.get("name"),
        user_email=session.get("email"),
        user_role=session.get("role"),
    )

# GET SYSTEM LOGS API

# Creates an API route used to retrieve system logs
@logs_bp.route("/api/admin/logs")

# Makes sure only an administrator can access the logs API
@admin_required
def get_logs():
    # Initializes database connection and cursor variables to None
    connection = None
    cursor = None

    # Starts error handling for retrieving logs
    try:
        # Connects to the MySQL database
        connection = get_db_connection()
        
        # Creates a dictionary cursor to fetch rows as dictionaries
        cursor = connection.cursor(dictionary=True)

        # Executes the query to retrieve the latest system logs
        cursor.execute(
            """
            SELECT
                log_id,
                user_name,
                role,
                action,
                details,
                ip_address,
                created_at
            FROM system_logs
            ORDER BY created_at DESC
            LIMIT 500
            """
        )

        # Fetches all log records from the query result
        logs = cursor.fetchall()

        # Loops through each log entry to format the creation date and time
        for log in logs:
            if log["created_at"]:
                log["created_at"] = log["created_at"].strftime("%Y-%m-%d %H:%M:%S")

        # Returns the successful response containing the logs list
        return jsonify({"success": True, "logs": logs})

    # Catches any errors that occur while loading logs
    except Exception as error:
        # Prints the error in the terminal for debugging
        print("Load logs error:", error)

        # Returns an error response if logs could not be loaded
        return (
            jsonify({"success": False, "message": "Could not load system logs."}),
            500,
        )

    # Ensures database resources are always closed
    finally:
        # Closes the database cursor if it exists
        if cursor:
            cursor.close()
        # Closes the database connection if it exists
        if connection:
            connection.close()