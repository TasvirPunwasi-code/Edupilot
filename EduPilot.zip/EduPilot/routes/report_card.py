# Imports Flask tools for routes, templates, JSON responses, request data, user sessions and response objects[cite: 10]
from flask import Blueprint, render_template, jsonify, request, session, make_response

# Imports HTML rendering for PDF generation using WeasyPrint[cite: 10]
from weasyprint import HTML

# Imports the function used to connect to the MySQL database[cite: 10]
from db import get_db_connection

# Imports the security check that allows only administrators[cite: 10]
from routes.security import admin_required

# Creates a Blueprint for all report card routes[cite: 10]
report_card_bp = Blueprint("report_card", __name__)

# REPORT CARD PAGE

# Creates the route used to open the report card page[cite: 10]
@report_card_bp.route("/admin/report-card")

# Makes sure only an administrator can access the report card page[cite: 10]
@admin_required
def report_card_page():
    # Loads the report card HTML page along with user session details[cite: 10]
    return render_template(
        "ReportCard.html",
        user_name=session.get("name"),
        user_role=session.get("role")
    )

# GET STUDENTS API

# Creates an API route used to retrieve all students for the report card[cite: 10]
@report_card_bp.route("/api/admin/report-card/students", methods=["GET"])

# Makes sure only an administrator can access the students API[cite: 10]
@admin_required
def report_card_students():
    # Connects to the MySQL database[cite: 10]
    connection = get_db_connection()
    
    # Creates a dictionary cursor to fetch rows as dictionaries[cite: 10]
    cursor = connection.cursor(dictionary=True)

    # Executes the query to retrieve student details ordered by name[cite: 10]
    cursor.execute("""
        SELECT
            student_id,
            student_name,
            student_number,
            grade,
            class_name
        FROM students
        ORDER BY student_name
    """)

    # Fetches all student records from the query result[cite: 10]
    students = cursor.fetchall()

    # Closes the database cursor and connection[cite: 10]
    cursor.close()
    connection.close()

    # Returns the list of students as a JSON response[cite: 10]
    return jsonify(students)

# GET REPORT DATA HELPER FUNCTION

# Creates a function that fetches and calculates report card data for a specific student and term[cite: 10]
def get_report_data(student_id, term):
    # Connects to the MySQL database[cite: 10]
    connection = get_db_connection()
    
    # Creates a dictionary cursor[cite: 10]
    cursor = connection.cursor(dictionary=True)

    # Executes the query to retrieve student information[cite: 10]
    cursor.execute("""
        SELECT
            student_id,
            student_name,
            student_number,
            grade,
            class_name
        FROM students
        WHERE student_id = %s
    """, (student_id,))

    # Fetches the student record[cite: 10]
    student = cursor.fetchone()

    # Checks if the student does not exist[cite: 10]
    if not student:
        # Closes the database cursor and connection before returning None[cite: 10]
        cursor.close()
        connection.close()
        return None

    # Executes the query to retrieve subject marks and calculate assessment averages[cite: 10]
    cursor.execute("""
        SELECT
            s.subject_id,
            s.subject_name,
            ROUND(AVG(CASE WHEN m.assessment_type LIKE 'Test%' THEN m.mark END), 2) AS test_average,
            ROUND(AVG(CASE WHEN m.assessment_type = 'Assignment' THEN m.mark END), 2) AS assignment_average,
            ROUND(AVG(CASE WHEN m.assessment_type = 'Exam' THEN m.mark END), 2) AS exam_average
        FROM student_subjects ss
        JOIN subjects s ON ss.subject_id = s.subject_id
        LEFT JOIN marks m ON m.student_id = ss.student_id
            AND m.subject_id = ss.subject_id
            AND m.term = %s
        WHERE ss.student_id = %s
        GROUP BY s.subject_id, s.subject_name
        ORDER BY s.subject_name
    """, (term, student_id))

    # Fetches all subject records[cite: 10]
    subjects = cursor.fetchall()

    # Closes the database cursor and connection[cite: 10]
    cursor.close()
    connection.close()

    # Initializes an empty list to store calculated final marks[cite: 10]
    final_marks = []

    # Loops through each subject to calculate the final mark[cite: 10]
    for subject in subjects:
        test = float(subject["test_average"]) if subject["test_average"] is not None else None
        assignment = float(subject["assignment_average"]) if subject["assignment_average"] is not None else None
        exam = float(subject["exam_average"]) if subject["exam_average"] is not None else None

        # Checks if test, assignment and exam averages are all available[cite: 10]
        if test is not None and assignment is not None and exam is not None:
            # Calculates the final mark using weighted averages (20% test, 20% assignment, 60% exam)[cite: 10]
            final_mark = round((test * 0.20) + (assignment * 0.20) + (exam * 0.60), 2)
            final_marks.append(final_mark)
        else:
            final_mark = None

        # Assigns the processed values back to the subject dictionary[cite: 10]
        subject["test_average"] = test
        subject["assignment_average"] = assignment
        subject["exam_average"] = exam
        subject["final_mark"] = final_mark

    # Calculates the overall average across all subjects[cite: 10]
    overall_average = round(sum(final_marks) / len(final_marks), 2) if final_marks else None

    # Returns the complete report data dictionary[cite: 10]
    return {
        "student": student,
        "term": term,
        "subjects": subjects,
        "overall_average": overall_average
    }

# GET REPORT CARD DATA API

# Creates an API route used to retrieve a student's report card data for a given term[cite: 10]
@report_card_bp.route("/api/admin/report-card/<int:student_id>", methods=["GET"])

# Makes sure only an administrator can access the report data API[cite: 10]
@admin_required
def report_card_data(student_id):
    # Gets the term parameter from the request query string[cite: 10]
    term = request.args.get("term", type=int)

    # Validates that the term is between 1 and 4[cite: 10]
    if term not in [1, 2, 3, 4]:
        return jsonify({
            "message": "Invalid term."
        }), 400

    # Retrieves the report data using the helper function[cite: 10]
    report = get_report_data(student_id, term)

    # Checks if the report or student was not found[cite: 10]
    if not report:
        return jsonify({
            "message": "Student not found."
        }), 404

    # Returns the report data as a JSON response[cite: 10]
    return jsonify(report)

# GENERATE REPORT PDF API

# Creates an API route used to generate and download a PDF version of the student's report card[cite: 10]
@report_card_bp.route("/admin/report-card/<int:student_id>/pdf", methods=["POST"])

# Makes sure only an administrator can generate the report PDF[cite: 10]
@admin_required
def generate_report_pdf(student_id):
    # Gets the term from the form data[cite: 10]
    term = request.form.get("term", type=int)

    # Validates that the term is between 1 and 4[cite: 10]
    if term not in [1, 2, 3, 4]:
        return "Invalid term.", 400

    # Retrieves the report data[cite: 10]
    report = get_report_data(student_id, term)

    # Checks if the report or student was not found[cite: 10]
    if not report:
        return "Student not found.", 404

    # Renders the HTML template for the PDF report[cite: 10]
    html = render_template(
        "ReportCardPDF.html",
        report=report,
        admin_name=session.get("name")
    )

    # Generates the PDF file from the HTML string using WeasyPrint[cite: 10]
    pdf = HTML(string=html, base_url=request.url_root).write_pdf()

    # Creates a Flask response with the PDF content[cite: 10]
    response = make_response(pdf)

    # Sets the response headers to display the PDF inline with a custom filename[cite: 10]
    response.headers["Content-Type"] = "application/pdf"
    response.headers["Content-Disposition"] = f'inline; filename="EduPilot_Report_{student_id}_Term_{term}.pdf"'

    # Returns the PDF response[cite: 10]
    return response