# Imports the wraps function so decorators keep the original function's name and other useful information.
from functools import wraps
# session stores information about the logged-in user. redirect sends the user to another page.
# jsonify converts Python data into a JSON response. request gives access to information about the current HTTP request.
from flask import session, redirect, jsonify, request

# This decorator checks whether a user is logged in before allowing access to a protected route.
def login_required(function):
    # Keeps the original function's name and metadata when it is wrapped by this decorator.
    @wraps(function)
    def wrapper(*args, **kwargs):
        # Check whether the user's session says they are authenticated.
        if not session.get("authenticated"):
            # If the request is being made to an API route, return a JSON error message instead of redirecting.
            if request.path.startswith("/api/"):
                return jsonify({
                    "success": False,
                    "message": "Authentication required."
                }), 401  # 401 means Unauthorized.
            # For normal web pages, send the user to the login page.
            return redirect("/login")
        # If the user is logged in, run the original function.
        return function(*args, **kwargs)
    return wrapper

# This decorator allows only administrators to access certain protected routes.
def admin_required(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        # First check whether the user is logged in.
        if not session.get("authenticated"):
            # Return a JSON error for unauthenticated API requests.
            if request.path.startswith("/api/"):
                return jsonify({
                    "success": False,
                    "message": "Authentication required."
                }), 401
            # Redirect normal users to the login page.
            return redirect("/login")

        # Check whether the logged-in user has the admin role.
        if session.get("role") != "admin":
            # Return a 403 error for API requests if the user does not have admin permission.
            if request.path.startswith("/api/"):
                return jsonify({
                    "success": False,
                    "message": "Admin access required."
                }), 403  # 403 means Forbidden.
            # Redirect non-admin users to the teacher dashboard.
            return redirect("/teacher/dashboard")

        # If the user is authenticated and is an admin, allow the original route to run.
        return function(*args, **kwargs)
    return wrapper

# This decorator allows only teachers to access certain protected routes.
def teacher_required(function):
    @wraps(function)
    def wrapper(*args, **kwargs):
        # Check whether the user is logged in.
        if not session.get("authenticated"):
            # Return a JSON error for API requests.
            if request.path.startswith("/api/"):
                return jsonify({
                    "success": False,
                    "message": "Authentication required."
                }), 401
            # Redirect unauthenticated users to the login page.
            return redirect("/login")

        # Check whether the logged-in user has the teacher role.
        if session.get("role") != "teacher":
            # Return a 403 error for API requests if the user does not have teacher permission.
            if request.path.startswith("/api/"):
                return jsonify({
                    "success": False,
                    "message": "Teacher access required."
                }), 403
            # Redirect non-teacher users to the admin dashboard.
            return redirect("/admin/dashboard")

        # If the user is authenticated and is a teacher, allow the original route to run.
        return function(*args, **kwargs)
    return wrapper