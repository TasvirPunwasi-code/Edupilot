# EduPilot coding review — 10 November 2026

## Updated
1. All 14 API JSON reads in `auth.py`, `chatbot.py`, `events.py`, `marks.py`, `students.py`, and `teachers.py` now accept malformed or non-object input gracefully. Missing or invalid JSON becomes an empty dictionary for existing endpoint validations.
2. Marks capture, single update, and bulk update reject `NaN`, positive infinity and negative infinity, as well as values outside 0–100. Bulk and capture endpoints reject non-object list entries before accessing fields.
3. Chatbot generation is stateless per request instead of sharing one conversation across all teachers. Existing multi-turn context is no longer retained.
4. Flask starts with debug mode disabled, with no dependency on absent localhost certificate files. `FLASK_USE_HTTPS=true` enables Secure cookies for HTTPS deployments; default is false for localhost HTTP.
5. Missing Flask secret key gives a clear startup error. Database connection now has a 10-second timeout.
6. Added missing Python requirements (`google-genai`, `weasyprint`).
7. Added `.env.example` and `.gitignore`. The private `.env` was intentionally excluded from the distributed ZIP; copy your own original `.env` back to the project before running.
8. Removed compiled Python caches (`__pycache__`, `*.pyc`) from distribution.

## Important limitations
- Syntax and offline unit checks do not confirm end-to-end operation with a configured MySQL database, email provider, Gemini service, or PDF/native libraries.
- Session cookies should be Secure in production with HTTPS. Default `FLASK_USE_HTTPS=false` is only for local HTTP development.
- Full CSRF protection has not been added across frontend forms and APIs; SameSite cookies are not a substitute.
- Report-card PDF generation may require native WeasyPrint libraries (Pango/Cairo) on Windows.
- Dependencies are listed without version locks; reproducible releases should pin/test versions.
- Chat requests are now independent; user-specific multi-turn chat requires separate, appropriately protected history management.
- The project contains many routes and interface files; this was a targeted reliability and security pass, not a verified full rewrite.

## Run
1. Make a virtual environment and activate it.
2. `pip install -r requirements.txt`
3. Create `.env` using `.env.example` (or restore your existing personal `.env` privately).
4. Set up MySQL and import `edupilot.sql` as appropriate.
5. `python app.py` then visit `http://127.0.0.1:5000`.
6. Test both roles, CRUD, marks, analytics, reporting, backups, password reset and chatbot with real integrations.
