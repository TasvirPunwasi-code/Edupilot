# Imports the os module to access environment variables
import os

# Waitress

# Imports Flask to create the application, request, session, redirect, url_for
from flask import Flask, request, session, redirect, url_for

# Imports load_dotenv to load variables from the .env file
from dotenv import load_dotenv

# Imports the student routes
from routes.students import students_bp

# Imports the teacher routes
from routes.teachers import teachers_bp

# Imports the event routes
from routes.events import events_bp

# Imports the AI chatbot routes
from routes.chatbot import chatbot_bp

# Imports the authentication and login routes
from routes.auth import auth_bp

# Imports the student marks routes
from routes.marks import marks_bp

# Imports the system backup routes
from routes.backup import backup_bp

# Imports the report card routes
from routes.report_card import report_card_bp

# Imports the report card routes
from routes.logs import logs_bp

# Loads environment variables from the .env file
load_dotenv()

# Creates the main Flask application
app = Flask(__name__)

# --- SESSION SECURITY CONFIGURATION ---
# Protects against XSS: prevents client-side JavaScript from accessing session cookies
app.config['SESSION_COOKIE_HTTPONLY'] = True

# Protects against eavesdropping: ensures cookies are only transmitted over HTTPS
app.config['SESSION_COOKIE_SECURE'] = os.getenv('FLASK_USE_HTTPS', 'false').lower() == 'true'

# Protects against CSRF: restricts sending cookies with cross-site requests
app.config['SESSION_COOKIE_SAMESITE'] = 'Lax'


# --- SESSION FINGERPRINT VERIFICATION ---
@app.before_request
def verify_session_fingerprint():
    # Only bypass check for public authentication routes and static files
    public_endpoints = [
        'auth.login_page',
        'auth.login',
        'auth.verify',
        'auth.resend_otp',
        'auth.about_page',
        'auth.support_page',
        'auth.privacy_page',
        'auth.term_page',
        'auth.request_password_change',
        'auth.verify_password_page',
        'auth.verify_password_otp',
        'auth.new_password_page',
        'auth.update_password',
        'auth.resend_password_otp',
        'static'
    ]

    if request.endpoint in public_endpoints:
        return

    # If a session exists, verify that IP and User-Agent match
    if 'user_id' in session:
        current_ip = request.remote_addr
        current_agent = request.headers.get('User-Agent')

        saved_ip = session.get('user_ip')
        saved_agent = session.get('user_agent')

        # If IP or Browser profile changes mid-session, wipe session and redirect
        if saved_ip != current_ip or saved_agent != current_agent:
            session.clear()
            return redirect(url_for('auth.login_page'))


# Runs after every request before the response is sent to the browser
@app.after_request
def prevent_cache(response):
    # Prevent caching across all responses so browsers never retain stale page views
    response.headers["Cache-Control"] = "no-store, no-cache, must-revalidate, private, max-age=0"
    response.headers["Pragma"] = "no-cache"
    response.headers["Expires"] = "0"
    return response

# Gets the Flask secret key from the environment variables
app.secret_key = os.getenv("FLASK_SECRET_KEY")
if not app.secret_key:
    raise RuntimeError("FLASK_SECRET_KEY must be configured in your .env file.")

# Registers the authentication routes with the main Flask application
app.register_blueprint(auth_bp)

# Registers the student routes with the main Flask application
app.register_blueprint(students_bp)

# Registers the teacher routes with the main Flask application
app.register_blueprint(teachers_bp)

# Registers the event routes with the main Flask application
app.register_blueprint(events_bp)

# Registers the AI chatbot routes with the main Flask application
app.register_blueprint(chatbot_bp)

# Registers the student marks routes with the main Flask application
app.register_blueprint(marks_bp)

# Registers the report card routes with the main Flask application
app.register_blueprint(report_card_bp)

# Registers the logs routes with the main Flask application
app.register_blueprint(logs_bp)

# Registers the system backup routes with the main Flask application
app.register_blueprint(backup_bp)

# Checks if this file is being run directly
if __name__ == "__main__":
    # For local development, HTTP works without certificates. In production use HTTPS
    # through a reverse proxy and set FLASK_USE_HTTPS=true.
    app.run(host="127.0.0.1", port=5000, debug=False)